

The Marco Polo Tutorial
	is an online-only resource to learn the basics of using Photon Unity Networking (PUN).
	Covered are: Connect, find a room, react to joining players, synchronizing positions and animations and more.
	This package includes the result of the tutorial but in best case, you implement each step while reading.
	
Disclaimer
	The results of the tutorial have been adjusted to better fit into this packge:
		The myThirdPersonController used here is a C# script (which saves some file moving).
		A 3D Text offers you info and to open the tutorial online.
		Some code will differ from the individual passages.
		Removed some of the "Monster" package's to reduce package size.