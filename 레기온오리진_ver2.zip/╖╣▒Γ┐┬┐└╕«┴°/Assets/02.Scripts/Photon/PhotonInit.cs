﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhotonInit : MonoBehaviour
{
    // App의 버전 정보
    public string version = "v1.0";

    private void Awake()
    {
        // 포톤 클라우드 접속
        PhotonNetwork.ConnectUsingSettings(version);
    }

    // 포톤 클라우드 접속에 실패한 경우 호출되는 콜백함수
    void OnJoinedLobby()
    {
        Debug.Log("로비 접속 성공!");
        PhotonNetwork.JoinRandomRoom();
    }

    // 무작위 룸 접속에 실패한 경우 호출되는 콜백함수
    void OnPhotonRandomJoinFailed()
    {
        Debug.Log("방이 없네!");

        // 룸 생성
        RoomOptions roomOptions = new RoomOptions();
        roomOptions.IsVisible = true;
        roomOptions.IsOpen = true;
        roomOptions.MaxPlayers = 6;
        PhotonNetwork.CreateRoom("room", roomOptions, null);
    }

    // 룸에 입장하면 호출되는 콜백 함수
    void OnJoinedRoom()
    {
        Debug.Log("방 입장!");
    }

    private void OnGUI()
    {
        // 화면 좌측 상단에 접속 과정 로그 출력
        GUILayout.Label(PhotonNetwork.connectionStateDetailed.ToString());
    }
}
