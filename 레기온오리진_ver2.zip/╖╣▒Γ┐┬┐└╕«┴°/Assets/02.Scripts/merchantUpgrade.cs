﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class merchantUpgrade : MonoBehaviour
{
    // Start is called before the first frame update
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("Player"))
        {
            other.gameObject.GetComponent<playerDamageCtrl>().attack_damage += 5;
            other.gameObject.GetComponent<playerDamageCtrl>().q_damage += 5;
            other.gameObject.GetComponent<playerDamageCtrl>().w_damage += 5;
            other.gameObject.GetComponent<playerDamageCtrl>().e_damage += 5;
            other.gameObject.GetComponent<playerDamageCtrl>().r_damage += 5;
        }
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
