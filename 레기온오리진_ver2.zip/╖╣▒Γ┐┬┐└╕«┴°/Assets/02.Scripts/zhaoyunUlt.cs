﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zhaoyunUlt : MonoBehaviour
{
    public Transform mousePos;
    public GameObject LightningBuff;

    public bool isOn = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (isOn == true)
        {
            Lightningbuff();
        }
    }


     

    void Lightningbuff()
    {

        LightningBuff.transform.position = mousePos.position;
        LightningBuff.transform.rotation = mousePos.rotation;

    }
}
