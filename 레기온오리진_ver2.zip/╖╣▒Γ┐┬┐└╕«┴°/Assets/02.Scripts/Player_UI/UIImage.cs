﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// 플레이씬의 플레이어 초상화 변경 스크립트
public class UIImage : MonoBehaviour
{
    public Image myImage; 
    public Sprite TestSprite; // 바뀌어질 초상화 - 짜오윤

    public RawImage image_Q;
    public RawImage image_W;
    public RawImage image_E;
    public RawImage image_R;

    public Texture Q;  // 바뀌어질 스킬 아이콘 - 짜오윤
    public Texture W;  // 바뀌어질 스킬 아이콘 - 짜오윤
    public Texture E;  // 바뀌어질 스킬 아이콘 - 짜오윤
    public Texture R;  // 바뀌어질 스킬 아이콘 - 짜오윤

    void Update()
    {
        if (PickCharacter.number == 1) // 짜오윤인 경우에 초상화와 스킬 아이콘 변경
        {
            myImage.sprite = TestSprite;
            image_Q.texture = Q;
            image_W.texture = W;
            image_E.texture = E;
            image_R.texture = R;
        }
    }
}
