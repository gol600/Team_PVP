﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerInformation : MonoBehaviour
{
    public Image HP;
    public Slider small_HP;
    public Text text; // hp text

    // Start is called before the first frame update
    void Start()
    {
        HP.fillAmount = 1; // 처음엔 풀피다.
        small_HP.value = 100f;
        text.text = HP.fillAmount * 100 + " / 100";
    }

    // Update is called once per frame
    void Update()
    {
        HP.fillAmount = GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().currHp / 100;
        small_HP.value = GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().currHp;
        text.text = HP.fillAmount * 100 + " / 100";
    }
}
