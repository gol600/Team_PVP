﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PickCharacter : MonoBehaviour
{
    public static int number = 0; // 기본값은 0 -> Tim

    public Image myImage;
    public Sprite TestSprite; //바뀌어질 이미지
   
    public void SetCharacterNumber()
    {
        number = 0; // 버튼 누르면 Tim으로 값이 됨
        myImage.sprite = TestSprite;
    }
}
