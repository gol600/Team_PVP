﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skill_E : MonoBehaviour
{
    public Image img_Skill;
    static public bool isCharging = false; // 스킬쿨타임중에는 true가 됨

    // Use this for initialization
    void Start()
    {
        img_Skill.fillAmount = 0; // 처음에 스킬 아이콘을 가리지 않음
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (isCharging == false)
            {
                StartCoroutine(CoolTime(10f));
            }
            else
                return;
        }
    }

    IEnumerator CoolTime(float cool)
    {
        isCharging = true;

        img_Skill.fillAmount = 1; // 버튼을 누르면 스킬 아이콘을 가림
        while (cool > 1.0f)
        {
            cool -= Time.deltaTime;
            img_Skill.fillAmount -= 1 * Time.deltaTime / cool;

            yield return null;
        }

        img_Skill.fillAmount = 0; // 스킬 아이콘을 가리지 않음
        isCharging = false;
    }
}
