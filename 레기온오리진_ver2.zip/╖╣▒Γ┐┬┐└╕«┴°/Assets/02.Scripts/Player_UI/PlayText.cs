﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; // UI 컨트롤을 위한 namespace 추가
using UnityEngine;

public class PlayText : MonoBehaviour
{
    public Text txtMsg; // 외부에서 접근 가능하도록 Text 객체를 선언

    void Start()
    {
        txtMsg.text = "Kill  0     Death  0";
        // txtMsg = GameObject.Find("txtMsg").guiText;
        StartCoroutine("ChangeFont");
    }

    IEnumerator ChangeFont()
    {        
        txtMsg.text = "Kill  0     Death  0";

        yield return new WaitForFixedUpdate();
    }
}
