﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems; // 버튼 클릭을 위한 event system
using UnityEngine.SceneManagement; // 씬 전환를 위해 namespace 추가

public class ESCScreen : MonoBehaviour
{
    public GameObject Panel; // 결과 창
    bool PanelFlag;

    void Start()
    {
        Panel.SetActive(false);
        PanelFlag = false;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if(PanelFlag == false)
            {
                Panel.SetActive(true);
                PanelFlag = true;
            }
            else
            {
                Panel.SetActive(false);
                PanelFlag = false;
            }

        }        
    }   
    
    public void Resume()
    {
        Panel.SetActive(false);  // resume 버튼 누르면 창을 없애요       
    }

    public void Exit()
    {
        // SceneManager.LoadScene("StartScene"); // exit 누르면 스타트씬으로 가여
        Application.Quit(); // 프로그램 종료
    }
}
