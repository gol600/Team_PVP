﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; // UI 컨트롤을 위한 namespace 추가
using UnityEngine;

public class StartText_Title : MonoBehaviour
{
    /*
    public Text txtMsg; // 외부에서 접근 가능하도록 Text 객체를 선언
    public bool change = false;
    int i = 255;

    void Start()
    {
        // txtMsg = GameObject.Find("txtMsg").guiText;
        StartCoroutine("ChangeFont");
    }

    IEnumerator ChangeFont()
    {
        while (true)
        {
            if (change == false)
            {
                i--;
                txtMsg.color = new Color(0, 0, 0, i);
                if (i < 0)
                {
                    change = true;
                }

            }
            else
            {
                i++;
                txtMsg.color = new Color(0, 0, 0, i);
                if (i > 255)
                {
                    change = false;
                }
            }
        }
        yield return new WaitForFixedUpdate();
    }*/
}
