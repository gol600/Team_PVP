﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // 씬 전환를 위해 namespace 추가

public class MainToPlay : MonoBehaviour
{
    public static bool scenechange = false;

    // 씬 전환을 Update 함수로 처리
    void Update()
    {
        if (FadeOut_Main.fdout == true)
        {
            scenechange = true;
            SceneManager.LoadScene("PlayScene-우창");
        }
    }
}
