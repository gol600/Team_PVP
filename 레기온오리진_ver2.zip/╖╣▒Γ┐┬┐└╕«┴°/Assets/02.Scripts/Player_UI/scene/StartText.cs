﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; // UI 컨트롤을 위한 namespace 추가
using UnityEngine;

public class StartText : MonoBehaviour
{
    public Text txtMsg; // 외부에서 접근 가능하도록 Text 객체를 선언

    void Start()
    {
        // txtMsg = GameObject.Find("txtMsg").guiText;
        StartCoroutine("ChangeFont");
    }
    IEnumerator ChangeFont()
    {
        //글자크기 
        int font = 20;     
        txtMsg.fontSize = font;

        bool font_control = false; // false로 초기화. false일경우 폰트를 늘려주고, true일경우 폰트를 줄임.
        while ( true )
        {
            if (font_control == false)
            {
                font++;
                txtMsg.fontSize = font;
                if(font > 35)
                {
                    font_control = true;
                }
                yield return new WaitForFixedUpdate();
            }
            else
            {
                font--;
                txtMsg.fontSize = font;
                if (font < 20) 
                {
                    font_control = false;
                }
                yield return new WaitForFixedUpdate();
            }
        }

        /*투명도
        for (float a = 1; a >= 0; a -= 0.01f)
        {
            txtMsg.material.color = new Vector4(0, 1, 0.5f, a);
            yield return new WaitForFixedUpdate();
        }*/
    }
}
