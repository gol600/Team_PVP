﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PickCharacter2 : MonoBehaviour
{
    public Image myImage;
    public Sprite TestSprite; //바뀌어질 이미지

    public void SetCharacterNumber()
    {
        PickCharacter.number = 1; // 버튼 누르면 짜오윤으로 값이 됨
        myImage.sprite = TestSprite;
    }
}
