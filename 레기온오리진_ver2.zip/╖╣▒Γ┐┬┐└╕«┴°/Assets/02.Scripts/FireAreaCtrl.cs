﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireAreaCtrl : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector3 mousePos;


    public GameObject areaSkill;
    //private PlayerCtrl pc;
    void Start()
    {
        //pc = GetComponent<PlayerCtrl>();
    }

    // Update is called once per frame
    void Update()
    {
        //mousePos = pc.temp;
        //Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //RaycastHit hit;
        //
        //// 마우스 클릭시 네비매쉬에 클릭 된 것
        //if (Physics.Raycast(ray, out hit))
        //{
        //    mousePos = hit.point;
        //}

    }

    void AreaFire()
    {
        
        Instantiate(areaSkill, mousePos, Quaternion.identity);
    }
}
