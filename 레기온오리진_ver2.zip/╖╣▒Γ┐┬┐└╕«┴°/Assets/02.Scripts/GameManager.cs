﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Utility;

public class GameManager : Photon.MonoBehaviour
{
    //정글몹 출현 위치
    public class JungleClass
    {
        int jungleTimer;
        GameObject jungle;
        bool isDead;

        public JungleClass(int time, GameObject _jungle, bool dead)
        {
            jungleTimer = time;
            jungle = _jungle;
            isDead = dead;
        }
        public void setJungleTime(int time)
        {
            jungleTimer = time;
        }
        public void setJungleObject(GameObject _jungle)
        {
            jungle = _jungle;
        }
        public void setJungleDead(bool dead)
        {
            isDead = dead;
        }

        public int getJungleTime()
        {
            return jungleTimer;
        }

        public GameObject getJungleObject()
        {
            return jungle;
        }
        public bool getJungleDead()
        {
            return isDead;
        }
    }


    public class minionClass
    {

        GameObject minion;
        bool isDead;

        bool reachDestination;
        public minionClass(GameObject _jungle, bool dead)
        {
            //this.destination = destination;
            minion = _jungle;
            //this.reachDestination = reachDestination;
            isDead = dead;
        }

        public void setminionObject(GameObject _jungle)
        {
            minion = _jungle;
        }
        //public void setReachDestination(bool rd)
        //{
        //    reachDestination = rd;
        //}
        public void setminionDead(bool dead)
        {
            isDead = dead;
        }


        public GameObject getminionObject()
        {
            return minion;
        }
        //public bool getReachDestination()
        //{
        //    return reachDestination;
        //}
        public bool getminionDead()
        {
            return isDead;
        }
    }
    public Transform[] points;
    private MoveAgent moveAgent;

    public Transform nightMerchantPoint;

    // ai 생성
    public Transform Aispawn;
    public GameObject Ai;
    public Transform Aispawn2;

    //정글몹 오브젝트
    public GameObject[] jungle;

    public GameObject merchant;

    public GameObject FireballPref;
    public GameObject LightningPref;
    public GameObject enemyRangeAtk;

    //리스폰 플레이어
    public GameObject[] spawnRed;
    public GameObject[] spawnBlue;

    //test
    public GameObject testSpawn;

    //카메라 로비
    public GameObject lobbyCam;

    //리스폰 주기
    public float createTime = 30.0f;

    //정글 캠프당 최대 정글몹 개체수
    public int maxJungle = 1;

    public int merchantRespond = 0;

    //게임오버 확인
    public bool isGameOver = false;
    public bool gameStart = false;  //게임 시작 여부
    public bool jungleTrigger = false; //게임 시작 후에 정글이 생성되는 여부

    public int state = 0;

    public int characterSelect;

    public int jungleCount;

    private GameObject merchantTree;

    public int merchantCreateTime;

    public int merchantDestroyTime;

    IEnumerator CreateMerchant()
    {
        while (!isGameOver)
        {
            if (merchant != null)
            {
                if (merchantRespond == 0)
                {
                    yield return new WaitForSeconds(merchantCreateTime);
                    merchantTree = Instantiate(merchant, new Vector3(nightMerchantPoint.position.x + Random.Range(-50, 50), 0, nightMerchantPoint.position.z + Random.Range(-50, 50)), Quaternion.Euler(0, Random.Range(0, 360), 0));
                    merchantRespond = 1;
                }
                else if (merchantRespond == 1)
                {
                    yield return new WaitForSeconds(merchantDestroyTime);

                    Destroy(merchantTree);
                    merchantRespond = 0;

                }
            }
        }
    }

    [Header("Object Pool")]
    //마법프리팹

    //재생성 카운트

    public int maxPool = 10;

    public List<int> timerPool = new List<int>();
    public List<GameObject> magicPool = new List<GameObject>();
    public List<GameObject> enemyPool = new List<GameObject>();
    public List<JungleClass> jungles = new List<JungleClass>();

    public static GameManager instance = null;

    public int count;//인원수

    public int magicTimer = 0;
    public int characcountR = 0;
    public int characcountB = 0;

    //test
    public int characterPick;
    //selectCharacterPref
    public GameObject playableCharacter;
    public GameObject playableCharacter2;

    void Connect()
    {
        PhotonNetwork.ConnectUsingSettings("v1.0");
    }

    void OnJoinedLobby()
    {
        state = 1;
    }
    void OnPhotonRandomJoinFailed()
    {
        PhotonNetwork.CreateRoom(null);
    }
    void OnJoinedRoom()
    {
        state = 2;
    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(this.gameObject);
        }

        DontDestroyOnLoad(this.gameObject);

        CreatePooling();
        Connect();
    }
    public GameObject GetLightningBeam()
    {
        for (int i = 0; i < magicPool.Count; i++)
        {
            if (magicPool[i].activeSelf == false && magicPool[i].tag == "Lightning")
            {
                return magicPool[i];
            }
        }
        return null;
    }
    public GameObject GetFireBall()
    {
        for (int i = 0; i < magicPool.Count; i++)
        {
            if (magicPool[i].activeSelf == false && magicPool[i].tag == "Fire")
            {
                return magicPool[i];
            }
        }
        return null;
    }

    public void CreatePooling()
    {
        GameObject objectPools = new GameObject("ObjectPools");

        for (int i = 0; i < maxPool; i++)
        {
            var obj = Instantiate<GameObject>(FireballPref, objectPools.transform);
            var obj2 = Instantiate<GameObject>(LightningPref, objectPools.transform);
            obj.name = "Bullet_" + i.ToString("00");
            obj.SetActive(false);
            obj2.name = "Lightning_" + i.ToString("00");
            magicPool.Add(obj);
            magicPool.Add(obj2);
            timerPool.Add(magicTimer);
        }
    }

    private float minionCount;
    // Start is called before the first frame update
    void Start()
    {

       
        //SetMove();

        nightMerchantPoint = GameObject.Find("암상인스폰지점").GetComponent<Transform>();
        points = GameObject.Find("JungleSpawnPoint").GetComponentsInChildren<Transform>();
        if (points.Length > 0)
        {
            StartCoroutine(this.CreateJungle());
        }
        StartCoroutine(CreateMerchant());
        minionCount = 0;
        //jungles.Add();
        // JH
        //points_Minion = GameObject.Find("MinionSpawnPoint").GetComponentsInChildren<Transform>();
        //if (points_Minion.Length > 0)
        //    StartCoroutine(this.CreateMinion());

    }

    // ********************************* 재현 코드 시작 *********************************
    // =================================================================================
    // 마우스 커서 텍스쳐 변경
    /*
    public Texture2D cursorTexture;
    public CursorMode cursorMode = CursorMode.Auto;
    public Vector2 hotSpot = Vector2.zero;

    void OnMouseEnter()
    {
        Cursor.SetCursor(cursorTexture, hotSpot, cursorMode);
    }
    void OnMouseExit()
    {
        Cursor.SetCursor(null, Vector2.zero, cursorMode);
    }
    */
    // =================================================================================
    // 미니언 생성 여부
    public bool minionTrigger = false;

    // 미니언 생성 위치
    public Transform[] Minion_point;
    //public Transform[] Minion_Gizmos;

    // 미니언 오브젝트
    public GameObject Minion_Redshort, Minion_Redlong;
    public GameObject Minion_Blueshort, Minion_Bluelong;

    // 리스폰 주기
    public float Minion_createTime = 10.0f;

    // 순찰 지점 저장
    public List<Transform> WayPoint;
    public List<Transform> Minion_Red_Bot, Minion_Red_Mid, Minion_Red_Top;
    public List<Transform> Minion_Blue_Bot, Minion_Blue_Mid, Minion_Blue_Top;

    public List<GameObject> testMinion;

    public List<GameObject> minions;

    // 미니언 경로 설정
    void SetMove()
    {
        var group = GameObject.Find("MinionSpawnPoint");

        if (group != null)
        {
            // WayPoint 리스트에 스폰 장소 모두 저장
            group.GetComponentsInChildren<Transform>(WayPoint);

            // Red Team 미니언 경로 설정
            // 1. Bot 경로 
            Minion_Red_Bot.Add(WayPoint[1]);
            Minion_Red_Bot.Add(WayPoint[4]);
            // 2. Mid 경로
            Minion_Red_Mid.Add(WayPoint[2]);
            Minion_Red_Mid.Add(WayPoint[4]);
            // 3. Top 경로
            Minion_Red_Top.Add(WayPoint[3]);
            Minion_Red_Top.Add(WayPoint[4]);

            // Blue Team 미니언 경로 설정
            // 1. Bot 경로 
            Minion_Blue_Bot.Add(WayPoint[1]);
            Minion_Blue_Bot.Add(WayPoint[5]);
            // 2. Mid 경로
            Minion_Blue_Mid.Add(WayPoint[2]);
            Minion_Blue_Mid.Add(WayPoint[5]);
            // 3. Top 경로
            Minion_Blue_Top.Add(WayPoint[3]);
            Minion_Blue_Top.Add(WayPoint[5]);

            /*
            // 경로 확인용
            Debug.Log("===== Minion_Blue_Bot =====");
            for (int i = 0; i < Minion_Blue_Bot.Count; i++)
                Debug.Log(Minion_Blue_Bot[i]);
            */
        }
    }

    IEnumerator CreateMinion()
    {
        //if(gameStart == true)
        //{
        //    yield return new WaitForSeconds(Minion_createTime);
        //    testMinion.Add(Instantiate(Minion_Redshort, Minion_point[1].position, Minion_point[1].rotation));
        //}
        while (!isGameOver)
        {
            if (gameStart == true)
            {
                yield return new WaitForSeconds(Minion_createTime);

                //minions.Add(new minionClass(Instantiate(Minion_Redshort, Minion_point[1].position, Minion_point[1].rotation), false));
                //minions.Add(new minionClass(Instantiate(Minion_Blueshort, Minion_point[0].position, Minion_point[0].rotation), false));
                testMinion.Add(Instantiate(Minion_Redshort, Minion_point[1].position, Minion_point[1].rotation));

            }
            else
            {
                yield return null;
            }
        }
        //    MinionMove blue_short_move = GameObject.Find("Minion_BlueShort").GetComponent<MinionMove>();
        //    MinionMove red_short_move = GameObject.Find("Minion_RedShort").GetComponent<MinionMove>();
        //
        //    while (!isGameOver)
        //    {
        //        // 게임 시작 후 10초 뒤에 미니언 생성
        //        if (minionTrigger == true)
        //        {
        //            // 10초 주기로 생성
        //            yield return new WaitForSeconds(10);
        //
        //            // 근거리 미니언 생성 * 3
        //            for (int i = 0; i < 3; i++)
        //            {
        //                red_short_move.wayPoints = Minion_Red_Bot;
        //                blue_short_move.wayPoints = Minion_Blue_Bot;
        //                Instantiate(Minion_Redshort, Minion_point[0].position, Minion_point[0].rotation);
        //                Instantiate(Minion_Blueshort, Minion_point[1].position, Minion_point[1].rotation);
        //
        //                red_short_move.wayPoints = Minion_Red_Mid;
        //                blue_short_move.wayPoints = Minion_Blue_Mid;
        //                Instantiate(Minion_Redshort, Minion_point[0].position, Minion_point[0].rotation);
        //                Instantiate(Minion_Blueshort, Minion_point[1].position, Minion_point[1].rotation);
        //
        //                red_short_move.wayPoints = Minion_Red_Top;
        //                blue_short_move.wayPoints = Minion_Blue_Top;
        //                Instantiate(Minion_Redshort, Minion_point[0].position, Minion_point[0].rotation);
        //                Instantiate(Minion_Blueshort, Minion_point[1].position, Minion_point[1].rotation);
        //
        //                yield return new WaitForSeconds(1.5f);
        //            }
        //        }
        //        else
        //            yield return null;
        //    }
    }

    //void OnEnable()
    //{
    //    StartCoroutine(CreateMinion());
    //}
    // =================================================================================
    // ********************************* 재현 코드 끝 *********************************

    IEnumerator CreateJungle()
    {
        while (!isGameOver)
        {
            int jungleCount2;  // 정글 몹 개체수
            jungleCount2 = (int)GameObject.FindGameObjectsWithTag("JUNGLE1").Length;

            // 게임 시작 후 15초 뒤에 정글 몹 생성
            if (gameStart == true)
            {
                yield return new WaitForSeconds(jungleCount);
                //tagJungle _jungles = new tagJungle(0, Instantiate(jungle, points[1].position, points[1].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[0], points[1].position, points[1].rotation), false));
                //_jungles = new tagJungle(0, Instantiate(jungle, points[2].position, points[2].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[1], points[2].position, points[2].rotation), false));
                //_jungles = new tagJungle(0, Instantiate(jungle, points[3].position, points[3].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[2], points[3].position, points[3].rotation), false));
                //_jungles = new tagJungle(0, Instantiate(jungle, points[5].position, points[5].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[3], points[5].position, points[5].rotation), false));
                //_jungles = new tagJungle(0, Instantiate(jungle, points[4].position, points[4].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[4], points[4].position, points[4].rotation), false));
                //_jungles = new tagJungle(0, Instantiate(jungle, points[6].position, points[6].rotation), false);
                jungles.Add(new JungleClass(0, Instantiate(jungle[5], points[6].position, points[6].rotation), false));
                jungleTrigger = true;
                gameStart = false;

            }
            else
            {
                yield return null;
            }


            //else if (jungleCount2 < maxJungle && jungleTrigger == true)
            //{
            //    if (jungle.tag == "JUNGLE1")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        jungles[0].setJungleObject(Instantiate(jungle, points[1].position, points[1].rotation));
            //    }
            //    if (jungle2.tag == "JUNGLE2")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        jungles[0].setJungleObject(Instantiate(jungle2, points[2].position, points[2].rotation));
            //    }
            //    if (jungle3.tag == "JUNGLE3")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        Instantiate(jungle3, points[3].position, points[3].rotation);
            //    }
            //    if (jungle4.tag == "JUNGLE4")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        Instantiate(jungle4, points[5].position, points[5].rotation);
            //    }
            //    if (jungle5.tag == "JUNGLE5")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        Instantiate(jungle5, points[4].position, points[4].rotation);
            //    }
            //    if (jungle6.tag == "JUNGLE6")
            //    {
            //        yield return new WaitForSeconds(createTime);
            //        Instantiate(jungle6, points[6].position, points[6].rotation);
            //    }
            //}
            //else
            //{
            //    yield return null;
            //}

        }
    }
    public bool minionCreateSuccess = false;
    public int minionNumber = 0;
    public int j = 0;
    void minionCreate()
    {
        minionCount += Time.deltaTime;
        if (minionCount >= Minion_createTime)
        {
            //minions.Add(new minionClass(Instantiate(Minion_Redshort, Minion_point[1].position, Minion_point[1].rotation), false));
            //minions.Add(new minionClass(Instantiate(Minion_Blueshort, Minion_point[0].position, Minion_point[0].rotation), false));

            testMinion.Add(Instantiate(Minion_Redshort, Minion_point[1].position, Minion_point[1].rotation));
            minions.Add(Instantiate(Minion_Blueshort, Minion_point[0].position, Minion_point[0].rotation));
            testMinion[minionNumber].GetComponent<MinionCtrl>().minionWay = j;
            minions[minionNumber].GetComponent<MinionCtrl>().minionWay = j;
            minionNumber++;
            j++;
            if (j >= 3)
            {
                j = 0;
            }
            
            minionCount = 0.0f;

        }//
        minionCreateSuccess = true;

    }
    public float startTimer;
    public bool gameStartOn = false;
    // Update is called once per frame
    void Update()
    {
        if (gameStartOn == false)
        {
            startTimer += Time.deltaTime;
        }
        if (startTimer >= 10)
        {
            gameStartOn = true;
            startTimer = 0;
            gameStart = true;
        }
        
        if (state < 2)
        {
            PhotonNetwork.JoinRandomRoom();
        }
        for (int i = 0; i < maxPool; i++)
        {

            if (magicPool[i].GetActive() == true)
            {
                timerPool[i]++;
                if (timerPool[i] % 300 == 0)
                {
                    magicPool[i].SetActive(false);
                    magicPool[i].GetComponentInChildren<CapsuleCollider>().enabled = true;
                    timerPool[i] = 0;
                }
            }


        }
        minionCreate();

        for (int i = 0; i < jungles.Count; i++)
        {
            if (jungles[i].getJungleTime() > 10)
            {
                Debug.Log("Jungle respond");
                jungles[i] = new JungleClass(0, Instantiate(jungle[i], points[i + 1].position, points[i + 1].rotation), false);

                //jungles[i].getJungleObject().GetComponent<DamageCtrl>().is_Die = false;

            }
            if (jungles[i].getJungleObject() != null)
            {
                if (jungles[i].getJungleObject().GetComponent<DamageCtrl>().is_Die == true)
                {
                    Destroy(jungles[i].getJungleObject());
                    jungles[i].setJungleDead(true);
                    Debug.Log("Jungle dead");
                    Debug.Log(jungles[i].getJungleDead());
                    Debug.Log(jungles[i].getJungleObject().tag);
                }
            }

        }

        for (int i = 0; i < jungles.Count; i++)
        {

            //Debug.Log(jungles[i].getJungleTime());
            if (jungles[i].getJungleDead() == true)
            {
                Debug.Log("JungleCount increase");
                jungles[i].setJungleTime(jungles[i].getJungleTime() + 1);
            }
        }



        if (state == 2)
        {
            state = 3;
            if (PickCharacter.number == 0)
            {
                Spawn(PickCharacter.number, "Tim");
                Instantiate(Ai, Aispawn.position, Aispawn.rotation);
            }
            if (PickCharacter.number == 1)
            {
                Spawn(PickCharacter.number, "zhaoyun");
                Instantiate(Ai, Aispawn2.position, Aispawn2.rotation);
            }
        }
        //StartCoroutine(CreateMinion());
    }
    void OnGUI()
    {
        switch (state)
        {

            case 3:
                //인게임
                break;

        }
    }
    void Spawn(int team, string character)
    {
        state = 3;
        // lobbyCam.SetActive(false);
        count++;
        GameObject objecply = new GameObject("Players");

        if (team == 0)
        {
            GameObject mySpawn = spawnRed[characcountR];

            GameObject myPlayer = PhotonNetwork.Instantiate(character, mySpawn.transform.position, mySpawn.transform.rotation, 0) as GameObject;
            myPlayer.transform.parent = objecply.transform;
            myPlayer.transform.localScale = new Vector3(2, 2, 2);
            myPlayer.GetComponent<PlayerCtrlTest>().enabled = true;

            if (myPlayer.GetComponent<CapsuleCollider>() != null)
            {
                myPlayer.GetComponent<CapsuleCollider>().enabled = true;
            }
            if (myPlayer.GetComponent<Animator>() != null)
            {
                myPlayer.GetComponent<Animator>().enabled = true;
            }
            if (myPlayer.GetComponent<FireCtrl>() != null)
            {
                myPlayer.GetComponent<FireCtrl>().enabled = true;
            }
            if (myPlayer.GetComponent<FireAreaCtrl>() != null)
            {
                myPlayer.GetComponent<FireAreaCtrl>().enabled = true;
            }
            if (myPlayer.GetComponent<DeathKnightCtrl>() != null)
            {
                myPlayer.GetComponent<DeathKnightCtrl>().enabled = true;
                characterPick = 0;
            }

            characcountR++;


        }
        if (team == 1)
        {
            GameObject mySpawn = spawnBlue[characcountB];

            GameObject myPlayer = PhotonNetwork.Instantiate(character, mySpawn.transform.position, mySpawn.transform.rotation, 0) as GameObject;
            myPlayer.transform.parent = objecply.transform;
            myPlayer.transform.localScale = new Vector3(4, 4, 4);
            myPlayer.GetComponent<PlayerCtrlTest>().enabled = true;

            if (myPlayer.GetComponent<CapsuleCollider>() != null)
            {
                myPlayer.GetComponent<CapsuleCollider>().enabled = true;
            }
            if (myPlayer.GetComponent<Animator>() != null)
            {
                myPlayer.GetComponent<Animator>().enabled = true;
            }
            if (myPlayer.GetComponent<FireCtrl>() != null)
            {
                myPlayer.GetComponent<FireCtrl>().enabled = true;
            }
            if (myPlayer.GetComponent<FireAreaCtrl>() != null)
            {
                myPlayer.GetComponent<FireAreaCtrl>().enabled = true;
            }
            if (myPlayer.GetComponent<ActionEffectManager>() != null)
            {
                myPlayer.GetComponent<ActionEffectManager>().enabled = true;
            }
            if (myPlayer.GetComponent<zhaoyunDemo>() != null)
            {
                myPlayer.GetComponent<zhaoyunDemo>().enabled = true;
            }
            if (myPlayer.GetComponent<LightningCtrl>() != null)
            {
                myPlayer.GetComponent<LightningCtrl>().enabled = true;
            }
            if (myPlayer.GetComponent<zhaoyunUlt>() != null)
            {
                myPlayer.GetComponent<zhaoyunUlt>().enabled = false;
                characterPick = 1;
            }



            characcountB++;
        }
    }
}
