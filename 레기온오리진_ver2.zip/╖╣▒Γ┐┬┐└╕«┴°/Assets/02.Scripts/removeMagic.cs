﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class removeMagic : MonoBehaviour
{
    // Start is called before the first frame update
    public float count = 0;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        count += Time.deltaTime;
        if(count >= 10)
        {
            Destroy(this.gameObject);
            count = 0;
        }
    }
}
