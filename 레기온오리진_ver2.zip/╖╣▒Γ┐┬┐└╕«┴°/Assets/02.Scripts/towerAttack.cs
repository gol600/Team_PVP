﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerAttack : MonoBehaviour
{
    private Transform target;
    public Transform targetTr;
    private Transform towerTr;
    public float attackDistance = 10.0f;
    public float targetDist = 0;
    public float playerDist = 0;
    public List<float> minionDist;

    public Transform firePos;
    public GameObject bullet;
    private GameObject bulletFire;

    private GameObject towerTarget;
    public bool targetPlayer;
    public bool targetMinions;

    public GameObject targetMinion;

    public GameObject player;
    private GameObject[] minions;

    public float attackInterval;
    public float maxAttackInterval = 3;
    Transform playerTr;
    Transform[] minionTr;
    // Start is called before the first frame update
    void Start()
    {
        towerTr = this.GetComponent<Transform>();
        minionDist = new List<float>();
    }

    void towerFire()
    {
        StartCoroutine(this.fire());
    }
    public float dists;
    public float searchDist;
    IEnumerator fire()
    {
        bulletFire = Instantiate(bullet, firePos.position, firePos.rotation);
        bulletFire.GetComponent<RFX1_Target>().Target = towerTarget;
        yield return null;
    }
    void getEnemy()
    {
        GameObject[] taggedEnemys = { null };
        GameObject closestEnemy = null;
        if (this.tag == "Red")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("Blue");

        }
        if (this.tag == "Blue")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("Red");

        }

        float closestDistSqr = Mathf.Infinity;//infinity 실제값?

        foreach (GameObject taggedEnemy in taggedEnemys)
        {
            Vector3 objectPos = taggedEnemy.transform.position;
            dists = Vector3.Distance(objectPos, transform.position);
            //원주민이 특정 거리 안으로 들어올때
            if (dists <= attackDistance)
            {
                // 그 거리가 제곱한 최단 거리보다 작으면
                if (dists < closestDistSqr)
                {
                    closestDistSqr = dists;
                    closestEnemy = taggedEnemy;
                }
            }
        }
        if (closestEnemy != null)
            towerTarget = closestEnemy;



    }
    // Update is called once per frame
    void Update()
    {
        
        //getEnemy();
        //targetTr = towerTarget.GetComponent<Transform>();
        if (GameManager.instance.gameStart == true)
        {

            player = GameObject.FindGameObjectWithTag("Player");
        }
        if (player ==null)
        {
            return;
        }
        if (player != null)
        {
            if ((this.tag == "BlueTeam" && player.GetComponent<PlayerCtrlTest>().redOrBlue == 1) || (this.tag == "RedTeam" && player.GetComponent<PlayerCtrlTest>().redOrBlue == 0)) return;
                playerTr = player.GetComponent<Transform>();
        
        }
        //if (minions != null)
        //{
        //    minionTr = minions.GetComponents<Transform>();
        //}
        if (player == null && minions == null)
        {
            return;
        }
        playerDist = Vector3.Distance(playerTr.position, towerTr.position);
        //for (int i = 0; i < minionTr.Length; i++)
        //{
        //    minionDist.Add(Vector3.Distance(minionTr[i].position, towerTr.position));
        //}
        //minionDist.Sort();
        if (towerTarget == null)
        {


            if(playerDist <= attackDistance)
            {

                towerTarget = player;
                targetPlayer = true;
            }
            //else
            //{
            //    getEnemy();
            //}
            
                

        }
        else
        {

            attackInterval += Time.deltaTime;
            if (attackInterval > maxAttackInterval)
            {
                towerFire();
                attackInterval = 0.0f;
            }
        }
        if(targetPlayer == true)
        {
            if(playerDist > attackDistance)
            {
                targetTr = null;
                towerTarget = null;
                targetPlayer = false;
            }
        }
        
    }


}
