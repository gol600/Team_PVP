﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class MoveAgent : MonoBehaviour
{
    private NavMeshAgent agent;
    private EnemyAI jungle;
    private Transform playerTr;

    private readonly float traceSpeed = 3.0f;
    private readonly float returnSpeed = 8.0f;

    private EnemyAtk enemyAtk;

    //private bool _returnToPoint;
    //
    //public bool returnToPoint
    //{
    //    get { return _returnToPoint; }
    //    set
    //    {
    //        _returnToPoint = value;
    //        if(_trace)
    //        {
    //            agent.speed = traceSpeed;
    //            moveInRange();
    //        }
    //    }
    //}

    private Vector3 _traceTarget;

    public Vector3 traceTarget
    {
        get { return _traceTarget; }
        set
        {
            _traceTarget = value;
            agent.speed = traceSpeed;

            TraceTarget(_traceTarget);
  
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        jungle = GetComponent<EnemyAI>();
        var player = GameObject.FindGameObjectWithTag("Player");
        if(player != null)
        {
            playerTr = GetComponent<Transform>();
        }
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = false;
        agent.speed = 0;

        enemyAtk = GetComponent<EnemyAtk>();
    }



    void moveInRange()
    {
        if (agent.isPathStale) return;
        if(jungle.state == EnemyAI.State.RETURN)
        {
            agent.destination = jungle.genPoints.position;
            agent.isStopped = false;
        }
    }

    void TraceTarget(Vector3 pos)
    {
        
            agent.destination = pos;
            agent.isStopped = false;
        
    }

    public void Stop()
    {
        agent.isStopped = true;
        agent.velocity = Vector3.zero;
        
        
    }

    // Update is called once per frame
    void Update()
    {

        //moveInRange();
    }
}
