﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JhaoyunAIAttack : MonoBehaviour
{
   

    private Animator animator;

    private Transform playerTr;
    private Transform aiTr;
    private JhaoyunAI JAI;
    private readonly int hash_attack = Animator.StringToHash("is_attack");
    private readonly int hash_q = Animator.StringToHash("is_q");
    private readonly int hash_w = Animator.StringToHash("is_w");
    private readonly int hash_e = Animator.StringToHash("is_e");
    private readonly int hash_r = Animator.StringToHash("is_r");
    private float nextAttack = 0.0f;
    private readonly float attackRate = 1.5f;
    private readonly float skillRate1 = 3.0f;
    private readonly float skillRate2 = 3.5f;
    private readonly float skillRate3 = 3.5f;
    private readonly float skillRate4 = 4.5f;

    private readonly float damping = 10.0f;
    public GameObject aura;
    public bool isAttack = false;
    public int state = 0;
    

    // Start is called before the first frame update
    void Start()
    {

        playerTr = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        aiTr = GetComponent<Transform>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (state != 1)
        {
            playerTr = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
            aiTr = GetComponent<Transform>();
            animator = GetComponent<Animator>();
            JAI = GetComponent<JhaoyunAI>();

        }
        state = 1;
        playerTr = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        if (isAttack)
            {
                
                 if (Time.time >= nextAttack)
                {

                        
                    if (JAI.atkskill == 0)
                    {
                        Attack();
                        nextAttack = Time.time + attackRate + Random.Range(0.0f, 0.2f);
                    }
                if (JAI.atkskill == 1)
                {
                    Skill1();
                    transform.LookAt(playerTr.position);
                    nextAttack = Time.time + skillRate1 + Random.Range(0.0f, 0.2f);
                }
                if (JAI.atkskill == 2)
                {
                    Skill2();
                    LightningCtrl fc = GetComponent<LightningCtrl>();
                    fc.mousePos = playerTr.position;
                    nextAttack = Time.time + skillRate2 + Random.Range(0.0f, 0.2f);
                }
                if (JAI.atkskill == 3)
                {
                    Skill3();
                    characterCtrl fc = GetComponent<characterCtrl>();
                    fc = new zhaoyunCtrl();
                    fc.LightningAura = aura;
                    fc.LightningAura.SetActive(true);

                    nextAttack = Time.time + skillRate3 + Random.Range(0.0f, 0.2f);
                }
                if (JAI.atkskill == 4)
                {
                    Skill4();
                    LightningCtrl fc = GetComponent<LightningCtrl>();
                    fc.mousePos = playerTr.position;
                    nextAttack = Time.time + skillRate4 + Random.Range(0.0f, 0.2f);
                }

            }
                
            }
        float dist = Vector3.Distance(playerTr.position, aiTr.position);
        if (dist <= 12)
        {
            Quaternion rot = Quaternion.LookRotation(playerTr.position - aiTr.position);
            aiTr.rotation = Quaternion.Slerp(aiTr.rotation, rot, Time.deltaTime * damping);
        }
    }
    void Attack()
    {
        animator.SetTrigger(hash_attack);
    }
    void Skill1()
    {
        animator.SetTrigger(hash_q);
    }
    void Skill2()
    {
        animator.SetTrigger(hash_w);
    }
    void Skill3()
    {
        animator.SetTrigger(hash_e);
    }
    void Skill4()
    {
        animator.SetTrigger(hash_r);
    }




}
