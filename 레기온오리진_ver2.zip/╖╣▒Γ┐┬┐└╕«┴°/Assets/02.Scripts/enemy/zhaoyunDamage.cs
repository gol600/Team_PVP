﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zhaoyunDamage : MonoBehaviour
{
    // Animator
    public Animator damage_anim;

    // HP
    bool is_Stun = false;
    bool is_Die = false;
    public float initHp = 100.0f;
    public float currHp = 100.0f;


    // MP
    public float initMP = 100.0f;
    public float currMP = 100.0f;

    // Attack
    public float attack_damage = 10.0f;
    public float attack_range = 3.0f;

    // Q
    public float q_damage = 15.0f;
    public float q_range = 2.0f;

    // W
    public float w_damage = 7.0f;
    public float w_range = 2.0f;

    // E
    public float e_damage = 8.0f;
    public float e_range = 2.0f;

    // R
    public float r_damage = 9.0f;
    public float r_range = 2.0f;

    // 피격


    private void Awake()
    {


    }

    void OnTriggerEnter(Collider coll)
    {

        Debug.Log("touch");
        // 칼 공격
        if (coll.gameObject.CompareTag("EnemySword"))
        {

            Debug.Log("hit");
            currHp -= GameObject.FindGameObjectWithTag(coll.transform.parent.tag).GetComponent<DamageCtrl>().attack_damage;
        }
        if (coll.gameObject.CompareTag("Sword"))
        {

            Debug.Log("hit");
            currHp -= GameObject.FindGameObjectWithTag(coll.transform.parent.tag).GetComponent<DamageCtrl>().attack_damage;
        }
        if (coll.gameObject.CompareTag("EnemyMagic"))
        {
            Debug.Log("magic Hit");
            
            currHp -= GameObject.FindGameObjectWithTag("JUNGLE3").GetComponent<DamageCtrl>().attack_range;
            if(coll.gameObject.GetComponent<CapsuleCollider>().enabled == true)
            {
                coll.gameObject.GetComponent<CapsuleCollider>().enabled = false;
            }
            //Destroy(coll.gameObject);
        }
        if (coll.gameObject.CompareTag("lightstrike"))
        {
            Debug.Log("magic Hit");

            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().w_damage;
          
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }
        
    // Update is called once per frame
    void Update()
    {
        
    }
}
