﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    //정글몹 상태
    public enum State
    {
        IDLE,
        TRACE,
        ATTACK,
        DIE,
        RETURN
    }
    //정글몹 타입(근접, 원거리)
    public enum Type
    {
        MELEE,
        RANGE
    }

    private bool plzAttack = false;

    public bool isDie = false;
    public bool isHit = false;
    public State state = State.IDLE;
    public Type monsterType = Type.MELEE;
    

    //플레이어 및 적 캐릭터 위치
    private Transform playerTr;
    private Transform jungleTr;

    //공격사거리 
    public float MeleeAttackDist;
    public float rangeAttackDist;
    private float attackDist;

    //사거리 관련 함수
    public float meleeTraceDist;
    public float rangeTraceDist;
    private float traceDist;
    public float returnDist;
    private float tempDist;
    public float genPointsDist;
    //생성된 포인트
    public Transform genPoints;
    private Transform[] points;

    private WaitForSeconds ws;

    //이동 제어 함수
    private MoveAgent moveAgent;

    private Animator animator;  //애니메이션 제어 함수

    private AnimatorStateInfo aniState;

    private readonly int hashMove = Animator.StringToHash("isMove");

    private EnemyAtk enemyAtk;

    public bool isWalk = false;

    private void Awake()
    {
        var player = GameObject.FindGameObjectWithTag("Player");//플레이어 오브젝트 추출
        points = GameObject.Find("JungleSpawnPoint").GetComponentsInChildren<Transform>();
        pointFind();
        if (player != null)
        {
            playerTr = player.GetComponent<Transform>();
        }

        jungleTr = GetComponent<Transform>();

        animator = GetComponent<Animator>();
        aniState = animator.GetCurrentAnimatorStateInfo(0);
        moveAgent = GetComponent<MoveAgent>();

        enemyAtk = GetComponent<EnemyAtk>();

        ws = new WaitForSeconds(0.3f);

        isDie = false;
        isHit = false;
    }

    private void pointFind()
    {
        if(this.tag == "JUNGLE1")
        {
            genPoints = points[1];
        }
        if (this.tag == "JUNGLE2")
        {
            genPoints = points[2];
        }
        if (this.tag == "JUNGLE3")
        {
            genPoints = points[3];
        }
        if (this.tag == "JUNGLE4")
        {
            genPoints = points[5];
        }
        if (this.tag == "JUNGLE5")
        {
            genPoints = points[4];
        }
        if (this.tag == "JUNGLE6")
        {
            genPoints = points[6];
        }


    }
    
    private void OnEnable()
    {
        StartCoroutine(checkType());
        StartCoroutine(Action());
    }

    IEnumerator Action()
    {
        while(!isDie)
        {
            yield return ws;

            switch(state)
            {
                case State.IDLE:
                    moveAgent.Stop();
                    animator.SetBool(hashMove, false);
                    if(monsterType == Type.MELEE)
                        this.GetComponent<hitBoxOnOff>().hitBox.GetComponent<BoxCollider>().enabled = false;
                    break;
                case State.TRACE:
                    moveAgent.traceTarget = playerTr.position;
                    animator.SetBool(hashMove, true);
                    if (animator.GetCurrentAnimatorStateInfo(0).IsName("walk") == false)
                    {
                        animator.Play("walk", -1, 0);
                        if (monsterType == Type.MELEE)
                            this.GetComponent<hitBoxOnOff>().hitBox.GetComponent<BoxCollider>().enabled = false;
                    }
                    break;
                case State.ATTACK:
                    moveAgent.Stop();
                    animator.SetBool(hashMove, false);
                    if (plzAttack == false)
                    {
                        plzAttack = true;
                        animator.Play("attack", -1, 0);
                    }
                    break;
                case State.RETURN:
                    moveAgent.traceTarget = genPoints.position;
                    animator.SetBool(hashMove, true);
                    if (animator.GetCurrentAnimatorStateInfo(0).IsName("walk") == false)
                    {
                        animator.Play("walk", -1, 0);
                        if (monsterType == Type.MELEE)
                            this.GetComponent<hitBoxOnOff>().hitBox.GetComponent<BoxCollider>().enabled = false;
                    }
                    break;
                case State.DIE:
                    moveAgent.Stop();
                    isDie = true;
                    if (animator.GetCurrentAnimatorStateInfo(0).IsName("death") == false)
                    {
                        animator.Play("death", -1, 0);
                        if(monsterType == Type.MELEE)
                        this.GetComponent<hitBoxOnOff>().hitBox.GetComponent<BoxCollider>().enabled = false;
                    }
                    break;
            }
            
        }
    }

    //타입 확인하는 이넘 함수
    IEnumerator checkType()
    {
        while (!isDie)
        {
            

            //플레이어와 정글몹 거리 계산
            float dist = Vector3.Distance(playerTr.position, jungleTr.position);
            float tempDist = Vector3.Distance(jungleTr.position, genPoints.position);

            //근접 혹은 원거리인지 파악 후 사거리 할당
            if (state != State.DIE)
            {
                if (monsterType == Type.MELEE)
                {
                    attackDist = MeleeAttackDist;
                    traceDist = meleeTraceDist;
                }
                else if (monsterType == Type.RANGE)
                {
                    attackDist = rangeAttackDist;
                    traceDist = rangeTraceDist;
                }

                if (dist < attackDist && isHit == true)
                {

                    state = State.ATTACK;
                }
                if (dist >= attackDist && isHit == true && tempDist < returnDist && plzAttack == false)
                {
                    state = State.TRACE;
                }
                if (tempDist > returnDist)
                {
                    state = State.RETURN;
                    isHit = false;
                }
                if (tempDist < genPointsDist && isHit == false)
                {
                    state = State.IDLE;


                }
            }
            yield return ws;
        }
        
    }

    //애니메이션 플레이
    void attackDone()
    {
        plzAttack = false;
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
