﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class Jmove : MonoBehaviour
{
    public Transform firstMove;
    private NavMeshAgent agent;
    private Transform playerTr;
    private readonly float moveSpeed = 2.0f;
    private readonly float traceSpeed = 3.0f;
    private readonly float returnSpeed = 10.0f;
    private JhaoyunAI JAI;
    private readonly int hash_run = Animator.StringToHash("is_run");
    public Animator animator;
    private Vector3 _traceTarget;
    public bool fmove;

    // Start is called before the first frame update
    public Vector3 tracePlayer
    {
        get { return _traceTarget;  }
        set
        {
            _traceTarget = value;
            agent.speed = traceSpeed;
            TracePlayer(_traceTarget);
        }
    }

    void Start()
    {
      
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = false;
       
    }
    // Update is called once per frame
    void Update()
    {

        playerTr = GameObject.FindWithTag("Player").GetComponent<Transform>();
        if (fmove == true)
        {
            firstMove = GameObject.FindGameObjectWithTag("Fmove").transform;
            agent.destination = firstMove.position;

            if (agent.velocity.sqrMagnitude >= 0.2f * 0.2f & agent.remainingDistance <= 0.5f)
            {
                agent.isStopped = true;
                fmove = false;
            }
        }
  
    }

    void  TracePlayer(Vector3 pos)
    {
        if (agent.isPathStale) return;
        agent.destination = pos;
        agent.isStopped = false;
    }

    public void Stop()
    {
        agent.isStopped = true;
        agent.velocity = Vector3.zero;
    }
}
