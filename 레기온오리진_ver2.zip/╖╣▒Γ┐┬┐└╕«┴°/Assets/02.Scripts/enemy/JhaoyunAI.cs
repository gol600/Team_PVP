﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class JhaoyunAI : MonoBehaviour
{
    GameObject player;
    public int state = 0;
    public enum FSMState
    {
        Stand = 0,
        Run,
        Trace,
        Attack,
        Skill1,
        Skill2,
        Skill3,
        Skill4,
        Death,
    }
    public FSMState curState = FSMState.Stand;


    private readonly int hash_run = Animator.StringToHash("is_run");
    private readonly int hash_attack = Animator.StringToHash("is_attack");
    private readonly int hash_die = Animator.StringToHash("is_die");
   


    private Transform _transform;
    private Transform playerTransform;
    private Transform minionTransform;
    private NavMeshAgent nvAgent;
    public Animator animator;
    public characterCtrl AIZHAO;
    public float traceDist;
    public float attackDist;
    public float skillDist;
    public int atkskill;
    private bool is_die= false;
    private JhaoyunAIAttack jhaoAttack;
    private Jmove movecon;
   
    private void Start()
    {
        _transform = this.gameObject.GetComponent<Transform>();
        playerTransform = GameObject.FindWithTag("Player").GetComponent<Transform>();
        //minionTransform = GameObject.FindWithTag("Minion").GetComponent<Transform>();
        nvAgent = this.gameObject.GetComponent<NavMeshAgent>(); 
        AIZHAO = new zhaoyunCtrl();
    }

    private void Update()
    {
       
        playerTransform = GameObject.FindWithTag("Player").GetComponent<Transform>();
        //minionTransform = GameObject.FindWithTag("Minion").GetComponent<Transform>();
        float dist = Vector3.Distance(playerTransform.position, _transform.position);
       // float mdist = Vector3.Distance(minionTransform.position, _transform.position);
        if (state != 1)
        {
            animator = this.gameObject.GetComponent<Animator>();
            jhaoAttack = this.gameObject.GetComponent<JhaoyunAIAttack>();
            traceDist = 20.0f;
            attackDist = 3.0f;
            skillDist = 12.0f;
            movecon = GetComponent<Jmove>();
            movecon.fmove = true;
            StartCoroutine(this.CheckState());
            StartCoroutine(this.CheckStateForAction());
        }
        state = 1;

    }
    IEnumerator CheckState()
    {
        while (!is_die)
        {
            if(movecon.fmove == true)
            {
                curState = FSMState.Run;
            }
            else
            {
                curState = FSMState.Stand;
                float dist = Vector3.Distance(playerTransform.position, _transform.position);
                atkskill = Random.Range(0,4);

                if (dist <= traceDist)
                {
                    curState = FSMState.Trace;
                }

                if (dist <= attackDist)
                {
                    curState = FSMState.Attack;   
                }
                if (dist > attackDist && dist < skillDist && atkskill != 0)
                {
                    
                    if (atkskill == 1)
                    {
                        curState = FSMState.Skill1;
                    }
                    if (atkskill == 2)
                    {
                        curState = FSMState.Skill2;
                    }
                    if (atkskill == 3)
                    {
                        curState = FSMState.Skill3;
                    }
                    if (atkskill == 4)
                    {
                        curState = FSMState.Skill4;
                    }
                }
               
                if(dist > traceDist)
                {
                    curState = FSMState.Stand;
                }
            }
            yield return new WaitForSeconds(1.0f);
           

        }
    }

    IEnumerator CheckStateForAction()
    {
        while(!is_die)
        {
            switch(curState)
            {
                case FSMState.Stand:
                    movecon.Stop();
                    jhaoAttack.isAttack = false;
                    animator.SetBool(hash_run, false);
                   // AIZHAO.Idle();
                    break;
                case FSMState.Run:
                    //   nvAgent.destination = playerTransform.position;
                    //  nvAgent.Resume();
                    jhaoAttack.isAttack = false;
                    animator.SetBool(hash_run, true);
                    break;
                case FSMState.Trace:

                    movecon.tracePlayer = playerTransform.position;
                    jhaoAttack.isAttack = false;
                    animator.SetBool(hash_run, true);
                    break;
                case FSMState.Attack:

                    movecon.Stop();
                    animator.SetBool(hash_run, false);
                    atkskill = 0;
                    if(jhaoAttack.isAttack == false)
                    {
                        jhaoAttack.isAttack = true;
                    }

                    break;
                case FSMState.Skill1:
                    movecon.Stop();
                    animator.SetBool(hash_run, false);
                    if (jhaoAttack.isAttack == false)
                    {
                        jhaoAttack.isAttack = true;
                    }

                    break;

                case FSMState.Skill2:
                    movecon.Stop();
                    animator.SetBool(hash_run, false);
                    if (jhaoAttack.isAttack == false)
                    {
                        jhaoAttack.isAttack = true;
                    }

                    break;
                case FSMState.Skill3:
                    movecon.Stop();
                    animator.SetBool(hash_run, false);
                    if (jhaoAttack.isAttack == false)
                    {
                        jhaoAttack.isAttack = true;
                    }

                    break;
                case FSMState.Skill4:
                    movecon.Stop();
                    animator.SetBool(hash_run, false);
                    if (jhaoAttack.isAttack == false)
                    {
                        jhaoAttack.isAttack = true;
                    }
                    break;
            }
            yield return null;
        }

    }
}