﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAtk : MonoBehaviour
{
    private AudioSource audio;

    private Animator animator;

    private readonly int hashAttack = Animator.StringToHash("Attack");

    private float nextAttack = 0.0f;

    public bool isAttack = false;

    public AudioClip fireSfx;


    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        audio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

    }


}
