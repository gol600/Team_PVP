﻿using System.Collections;
using System.Collections.Generic;
//using System.Diagnostics;
using UnityEngine;
using UnityEngine.AI;

public class characterCtrl : MonoBehaviour
{
    public Animator anim;
    [HideInInspector]
    public readonly int hash_run = Animator.StringToHash("is_run");
    public readonly int hash_attack = Animator.StringToHash("is_attack");
    public readonly int hash_die = Animator.StringToHash("is_die");

    public bool isOn;
    public GameObject LightningAura;
    public GameObject body;
    public GameObject Bone_wp_R;
    // Start is called before the first frame update
    public virtual void Start()
    {
        //anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    public virtual void Update()
    {
        
    }

    public virtual void Idle()
    {
        anim.SetBool(hash_run, false);
        anim.SetBool(hash_attack, false);
    }

    public virtual void Attack()
    {
        Debug.Log("Parent Attack");
    }

    public virtual void Run()
    {
        Debug.Log("Parent Run");
    }

    public virtual void Skill1()
    {
        Debug.Log("Parent skill1");
    }

    public virtual void Skill2()
    {
        Debug.Log("Parent skill1");
    }
    public virtual void Skill3()
    {
        Debug.Log("Parent skill1");
    }

    public virtual void Skill4()
    {
        Debug.Log("Parent skill1");
    }

    public virtual void Die()
    {
        Debug.Log("Parent skill1");
    }
}
