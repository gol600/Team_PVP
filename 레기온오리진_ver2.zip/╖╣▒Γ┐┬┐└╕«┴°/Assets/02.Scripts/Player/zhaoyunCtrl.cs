﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zhaoyunCtrl : characterCtrl
{

    public override void Start()
    {
        base.Start();
    }
    public override void Update()
    {
        base.Update();
    }
    public override void Idle()
    {
        base.Idle();
    }


    public override void Attack()
    {

        anim.Play("Attack", -1, 0);
    }

    public override void Run()
    {
        anim.SetBool("is_run", true);

        anim.Play("Run", -1, 0);
    }



    public override void Skill1()
    {

        anim.Play("Death", -1, 0);
    }
    public override void Skill2()
    {
        anim.Play("Magic2", -1, 0);
    }
    public override void Skill3()
    {


        anim.Play("Ultimate", -1, 0);
    }

    public override void Skill4()
    {

        if(isOn == true)
            LightningAura.SetActive(true);
        else if(isOn == false)
            LightningAura.SetActive(false);
        anim.Play("Victory", -1, 0);
        
    }

    public override void Die()
    {


        anim.Play("Die", -1, 1);
    }
}
