﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerDamageCtrl : MonoBehaviour
{
    // Animator
    public Animator damage_anim;

    // HP
    bool is_Stun = false;
    bool is_Die = false;
    public float initHp = 100.0f;
    public float currHp = 100.0f;


    // MP
    public float initMP = 100.0f;
    public float currMP = 100.0f;

    // Attack
    public float attack_damage = 5.0f;
    public float attack_range = 2.0f;

    // Q
    public float q_damage = 15.0f;
    public float q_range = 2.0f;

    // W
    public float w_damage = 7.0f;
    public float w_range = 2.0f;

    // E
    public float e_damage = 8.0f;
    public float e_range = 2.0f;

    // R
    public float r_damage = 9.0f;
    public float r_range = 2.0f;

    // 피격


    private void Awake()
    {


    }

    void OnTriggerEnter(Collider coll)
    {

        Debug.Log("touch");
        // 칼 공격
        if (coll.gameObject.CompareTag("EnemySword"))
        {

            Debug.Log(coll.tag);
            currHp -= GameObject.FindGameObjectWithTag("JUNGLE2").GetComponent<DamageCtrl>().attack_damage;
        }
        if(coll.gameObject.CompareTag("EnemyMagic"))
        {
            Debug.Log("magic Hit");
            
            currHp -= GameObject.FindGameObjectWithTag("JUNGLE3").GetComponent<DamageCtrl>().attack_range;
            //if(coll.gameObject.GetComponent<CapsuleCollider>().enabled == true)
            //{
            //    coll.gameObject.GetComponent<CapsuleCollider>().enabled = false;
            //}
            //Destroy(coll.gameObject);
        }
        if(coll.gameObject.CompareTag("towerMagic"))
        {
            currHp -= GameObject.FindGameObjectWithTag("BlueTeam").GetComponent<towerDamageCtrl>().attack_damage;
            Destroy(coll.gameObject);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
