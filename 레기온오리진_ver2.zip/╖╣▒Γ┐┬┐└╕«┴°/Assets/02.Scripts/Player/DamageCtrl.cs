﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageCtrl : MonoBehaviour
{
    // Animator
    

    // HP
    public bool is_Stun = false;
    public bool is_Die = false;
    public float initHp = 100.0f;
    public float currHp = 100.0f;

    // MP
    public float initMP = 100.0f;
    public float currMP = 100.0f;

    // Attack
    public float attack_damage = 5.0f;
    public float attack_range = 2.0f;

    // Q
    public float q_damage = 6.0f;
    public float q_range = 2.0f;

    // W
    public float w_damage = 7.0f;
    public float w_range = 2.0f;

    // E
    public float e_damage = 8.0f;
    public float e_range = 2.0f;

    // R
    public float r_damage = 9.0f;
    public float r_range = 2.0f;

    public bool playerHit;
    public bool minionHit;
    public bool enemyHit;
    // 피격

    void isDeadTrue()
    {
        is_Die = true;
    }


    void OnTriggerEnter(Collider coll)
    {
        
        Debug.Log("Enemytouch");
        
        
        // 칼 공격
        //Debug.Log(coll.gameObject.tag);
        if (coll.gameObject.CompareTag("Sword"))
        {
            Debug.Log("hit");
            GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().isHit = true;
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().attack_damage;


        }
        if(coll.gameObject.CompareTag("FireMagic"))
        {
            Debug.Log("Magichit");
            GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().isHit = true;
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().q_damage;
            
            //Destroy(this);
        }
        if(coll.gameObject.CompareTag("FireExplosion"))
        {
            Debug.Log(this.tag);
            Debug.Log(coll.tag);
            if(this.tag != "AI")
            GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().isHit = true;
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().r_damage;
        }
        


    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(this.currHp <= 0.0f)
        {
            GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().state = EnemyAI.State.DIE;
        }
    }
}
