﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.AI;
using UnityStandardAssets.Utility;

public class PlayerCtrlTest : MonoBehaviour
{

    [HideInInspector]
    //public Animator anim;

    NavMeshAgent agent;  // 길찾기 알고리즘 추가

    // 캐릭터 관련 변수
    public float initHp = 100.0f;
    public float currHp = 100.0f;
    public float moveSpeed = 2.0f;
    public float attack_range = 2.0f;
    public float q_range = 2.0f;
    public float w_range = 2.0f;
    public float e_range = 2.0f;
    public float r_range = 2.0f;

    public State state = State.IDLE;
    public bool is_Die = false;

    private readonly int hash_run = Animator.StringToHash("is_run");
    private readonly int hash_attack = Animator.StringToHash("is_attack");
    private readonly int hash_die = Animator.StringToHash("is_die");

    // 부활시간 측정
    Stopwatch sw = new Stopwatch();
    private const string enemyTag = "Enemy";


    public GameObject hitBoxCtrl;


    //character select
    public characterCtrl player;

    //블루팀 레드팀 구분 변수
    public int redOrBlue = 0;

    public GameObject Aura;

    private WaitForSeconds ws;
    public int selectTest;

    //캠 추적을 위한 photon view 및 추가 캠 게임 오브젝트
    private PhotonView pv = null;
    public Transform camPivot;

    // Start is called before the first frame update
    void Start()
    {

        agent = GetComponent<NavMeshAgent>();
        //anim = GetComponent<Animator>();
        if (GameManager.instance.characterPick == 0)
        {
            player = new DeathKnightCtrl();
            redOrBlue = 0;
           
        }

        if (GameManager.instance.characterPick == 1)
        {
            player = new zhaoyunCtrl();
            redOrBlue = 1;
         
        }
        ws = new WaitForSeconds(0.3f);
        player.anim = GetComponent<Animator>();

        player.LightningAura = Aura;

        pv = GetComponent<PhotonView>();
        if (pv.isMine)
        {
            Camera.main.GetComponent<SmoothFollow>().target = camPivot;
        }
        agent.speed = 10;
        agent.angularSpeed = 1000;
        agent.acceleration = 100;
    }

    private void OnEnable()
    {
        StartCoroutine(Action());
    }

    IEnumerator Action()
    {
        while (!is_Die)
        {
            yield return ws;

            switch (state)
            {
                case State.IDLE:
                    break;

                case State.WALK:
                    break;

                case State.RUN:
                    break;

                case State.ATTACK:
                    break;

                case State.SKILL1:
                    break;

                case State.SKILL2:
                    break;

                case State.SKILL3:
                    break;

                case State.SKILL4:
                    break;
                case State.DIE:

                    break;
            }
        }
    }
    // Update is called once per frame
    RaycastHit hit2;
    public bool q = false;
    public bool w = false;
    public bool e = false;
    public bool r = false;
    public float qCool = 0.0f;
    public float wCool = 0.0f;
    public float eCool = 0.0f;
    public float rCool = 0.0f;
    void Update()
    {
        if (q == true)
        {
            qCool += Time.deltaTime;
            if(qCool >= 4)
            {
                qCool = 0;
                q = false;
            }
        }
        if (w == true)
        {
            wCool += Time.deltaTime;
            if (wCool >= 6)
            {
                wCool = 0;
                w = false;
            }
        }
        if (e == true)
        {
            eCool += Time.deltaTime;
            if (eCool >= 8)
            {
                eCool = 0;
                e = false;
            }
        }
        if (r== true)
        {
            rCool += Time.deltaTime;
            if (rCool >= 10)
            {
                rCool = 0;
                r = false;
            }
        }
        if (pv.isMine)
        {
            // 플레이어 위치
            Vector3 myPos = this.gameObject.transform.position;

            // 캐릭터가 목표지점 도착할경우
            if (agent.remainingDistance <= 0.0f)
            {
                //hitBoxCtrl.GetComponent<BoxCollider>().enabled = false;
                player.Idle();
                //anim.Play("Idle01", -1, 0);
            }

            // ************************************ MOUSE ************************************
            // 마우스 '좌'
            if (Input.GetMouseButtonDown(0))
            {
                player.Attack();

                agent.SetDestination(transform.position);


                Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);
                float midPoint = (transform.position - Camera.main.transform.position).magnitude;
                transform.LookAt(mouseRay.origin + mouseRay.direction * midPoint);

            }

            // 마우스 '우'
            if (Input.GetMouseButtonDown(1))
            {

                // 스피드에 따른 애니메이션 변화
                //anim.Play("Run", -1, 0);
                if (player.anim.GetBool("is_run") == false)
                {
                    // hitBoxCtrl.GetComponent<BoxCollider>().enabled = false;
                    player.Run();

                }
                // ray로 마우스 클릭 위치 판별
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;

                // 마우스 클릭시 네비매쉬에 클릭 된 것
                if (Physics.Raycast(ray, out hit))
                    agent.SetDestination(hit.point);
            }
            // *******************************************************************************

            // ************************************ SKILL ************************************
            // 'Q'

            if (Input.GetKeyDown(KeyCode.Q))
            {
                if (q == false)
                {
                    Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);
                    float midPoint = (transform.position - Camera.main.transform.position).magnitude;


                        transform.LookAt(mouseRay.origin + mouseRay.direction * midPoint);
                    player.Skill1();
                    agent.SetDestination(transform.position);
                    q = true;
                }
            }

            // 'W'
            if (Input.GetKeyDown(KeyCode.W))
            {
                //anim.Play("Skill02", -1, 1);
                if (w == false)
                {
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    RaycastHit hit;
                    player.Skill2();

                    LightningCtrl fc = GetComponent<LightningCtrl>();
                    if (Physics.Raycast(ray, out hit) && GameManager.instance.characterPick == 1)
                        fc.mousePos = hit.point;
                    agent.SetDestination(transform.position);
                    w = true;
                }

            }

            // 'E'
            if (Input.GetKeyDown(KeyCode.E))
            {
                if (e == false)
                {
                    Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);
                    float midPoint = (transform.position - Camera.main.transform.position).magnitude;

                    if (GameManager.instance.characterPick == 0)
                        transform.LookAt(mouseRay.origin + mouseRay.direction * midPoint);
                    if (GameManager.instance.characterPick == 1)
                        if (player.isOn == false)
                            player.isOn = true;
                        else if (player.isOn == true)
                            player.isOn = false;
                    player.Skill4();
                    //anim.Play("Skill04", -1, 1);

                    agent.SetDestination(transform.position);
                    e = true;
                }
            }

            // 'R'
            if (Input.GetKeyDown(KeyCode.R))
            {
                //R스킬 누르면 스킬 눌렀을때 마우스 좌표를 fireAreaCtrl 스크립트로 전달
                if (r == false)
                {
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    RaycastHit hit;

                    //anim.Play("Skill03", -1, 1);
                    player.Skill3();
                    // 마우스 클릭시 네비매쉬에 클릭 된 것
                    FireAreaCtrl fc = GetComponent<FireAreaCtrl>();
                    if (Physics.Raycast(ray, out hit) && GameManager.instance.characterPick == 0)
                        fc.mousePos = hit.point;

                    agent.SetDestination(transform.position);
                    r = true;
                }
            }
            // *******************************************************************************
            if(Input.GetKeyDown(KeyCode.Return))
            {
                GameManager.instance.gameStart = true;
            }
            // ************************************ DAMAGE ************************************
            if (Input.GetKeyDown(KeyCode.J))
            {
                currHp = 0;
            }

            if (currHp == 0)
            {
                is_Die = true;
            }
            // 사망 시
            if (is_Die)
            {
                // 애니메이션 실행


                //anim.SetBool(hash_run, false);

                is_Die = false;
                currHp = 1;
                player.Die();
                //anim.Play("Die", -1, 1);
                // 시간 측정
                sw.Start();
            }

            // 부활시간 도달시
            if (sw.ElapsedMilliseconds == 10)
            {
                // 시간 측정 초기화
                sw.Stop();
                sw.Reset();

                // 부활
                is_Die = false;
                transform.position = new Vector3(0, 0, 0);
            }
        }
        // *******************************************************************************
    }



    // 사망
    void dead()
    {
        //anim.enabled = false;
    }
}
