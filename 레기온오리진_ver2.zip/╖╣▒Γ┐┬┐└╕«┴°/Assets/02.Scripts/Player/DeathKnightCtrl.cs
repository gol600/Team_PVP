﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathKnightCtrl : characterCtrl
{
    public override void Start()
    {
        base.Start();
    }
    public override void Update()
    {
        base.Update();
    }
    public override void Idle()
    {
        base.Idle();
    }
    

    public override void Attack()
    {
        anim.Play("Attack01", -1, 1);
    }
    
    public override void Run()
    {
        anim.SetBool("is_run", true);
        
        anim.Play("Run", -1, 0);
    }

    public override void Skill1()
    {


        anim.Play("Skill01", -1, 1);
    }
    public override void Skill2()
    {


        anim.Play("Skill02", -1, 1);
    }
    public override void Skill3()
    {


        anim.Play("Skill03", -1, 1);
    }

    public override void Skill4()
    {


        anim.Play("Skill04", -1, 1);
    }

    public override void Die()
    {


        anim.Play("Die", -1, 1);
    }
}
