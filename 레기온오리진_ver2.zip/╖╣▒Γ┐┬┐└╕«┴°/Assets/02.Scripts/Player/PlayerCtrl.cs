﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.AI;

public enum State
{
    IDLE,
    WALK,
    RUN,
    ATTACK,
    SKILL1,
    SKILL2,
    SKILL3,
    SKILL4,
    DIE
}

public class PlayerCtrl : MonoBehaviour
{
    [HideInInspector]
    public Animator anim;

    NavMeshAgent agent;  // 길찾기 알고리즘 추가
    
    // 캐릭터 관련 변수
    public float initHp = 100.0f;
    public float currHp = 100.0f;
    public float moveSpeed = 2.0f;
    public float attack_damage = 5.0f;
    public float attack_range = 2.0f;
    public float q_range = 2.0f;
    public float w_range = 2.0f;
    public float e_range = 2.0f;
    public float r_range = 2.0f;

    //public 스크립트이름 Enemy;

    public State state = State.IDLE;
    public bool is_Die = false;

    private readonly int hash_run = Animator.StringToHash("is_run");
    private readonly int hash_attack = Animator.StringToHash("is_attack");
    private readonly int hash_die = Animator.StringToHash("is_die");

    // 부활시간 측정
    Stopwatch sw = new Stopwatch();
    bool is_hit = false;
    GameObject enemy_obj = null;
    private const string enemyTag = "Enemy";
    private const string enemyfireTag = "Enemy_Fire";

    private WaitForSeconds ws;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(0, 0, 0);
        agent = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();

        ws = new WaitForSeconds(0.3f);
    }

    private void OnEnable()
    {
        StartCoroutine(Action());
    }

    IEnumerator Action()
    {
        while (!is_Die)
        {
            yield return ws;

            switch (state)
            {
                case State.IDLE:
                    break;

                case State.WALK:
                    break;

                case State.RUN:
                    break;

                case State.ATTACK:
                    break;

                case State.SKILL1:
                    break;

                case State.SKILL2:
                    break;

                case State.SKILL3:
                    break;

                case State.SKILL4:
                    break;
                case State.DIE:
                    
                    break;
            }
        }
    }
    // Update is called once per frame
    void Update()
    {
        // 플레이어 위치
        Vector3 myPos = this.gameObject.transform.position;

        // 캐릭터가 목표지점 도착할경우
        if (agent.remainingDistance <= 0.0f)
        {
            anim.SetBool(hash_run, false);
            anim.SetBool(hash_attack, false);
            //anim.Play("Idle01", -1, 0);
        }

        // ************************************ MOUSE ************************************
        // 마우스 '좌'
        if (Input.GetMouseButtonDown(0))
        {
            // 애니메이션 실행
            anim.Play("Attack01", -1, 1);

            // 위치 고정
            agent.SetDestination(transform.position);

            is_hit = true;
        }

        // 마우스 '우'
        if (Input.GetMouseButtonDown(1))
        {
            // 스피드에 따른 애니메이션 변화
            anim.Play("Run", -1, 0);

            // ray로 마우스 클릭 위치 판별
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            // 마우스 클릭시 네비매쉬에 클릭 된 것
            if (Physics.Raycast(ray, out hit))
                agent.SetDestination(hit.point);
        }
        // *******************************************************************************

        // ************************************ SKILL ************************************
        // 'Q'
        if (Input.GetKeyDown(KeyCode.Q))
        {
            anim.Play("Skill01", -1, 1);

            agent.SetDestination(transform.position);
        }

        // 'W'
        if (Input.GetKeyDown(KeyCode.W))
        {
            anim.Play("Skill02", -1, 1);

            agent.SetDestination(transform.position);
        }
        
        // 'E'
        if (Input.GetKeyDown(KeyCode.E))
        {
            Vector3 pos = Input.mousePosition;
            pos.z = 10;
            Vector3 target = Camera.main.ScreenToWorldPoint(pos);

            transform.LookAt(target);
            anim.Play("Skill04", -1, 1);

            agent.SetDestination(transform.position);
        }

        // 'R'
        if (Input.GetKeyDown(KeyCode.R))
        {
            //R스킬 누르면 스킬 눌렀을때 마우스 좌표를 fireAreaCtrl 스크립트로 전달
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            anim.Play("Skill03", -1, 1);

            // 마우스 클릭시 네비매쉬에 클릭 된 것
            FireAreaCtrl fc = GetComponent<FireAreaCtrl>();
            if (Physics.Raycast(ray, out hit))
                fc.mousePos = hit.point;

            agent.SetDestination(transform.position);
        }
        // *******************************************************************************

        // ************************************ DAMAGE ************************************
        if (Input.GetKeyDown(KeyCode.J))
        {
            currHp = 0;
        }
        
        // 사망 시
        if (is_Die)
       {
            // 애니메이션 실행


            //anim.SetBool(hash_run, false);

           is_Die = false;
           currHp = 1;
           anim.Play("Die", -1, 1);
           // 시간 측정
           sw.Start();
       }

        // 부활시간 도달시
        if(sw.ElapsedMilliseconds == 10)
        {
            // 시간 측정 초기화
            sw.Stop();
            sw.Reset();

            // 부활
            is_Die = false;
            transform.position = new Vector3(0, 0, 0);
        }
        // *******************************************************************************
    }

    // ************************************ EVENT ************************************
    // 피격
    void OnTriggerEnter(Collider coll)
    {
        if (coll.tag == enemyfireTag)
        {
            anim.Play("Damage", -1, 1);
            Destroy(coll.gameObject);

            currHp -= 5.0f;

            if (currHp <= 0)
                is_Die = true;
        }
    }

    // 사망
    void dead()
    {
        anim.enabled = false;
    }
    // *******************************************************************************
}

// 마우스 위치로 기본공격
// 화염구 위치 조정 
// 스킬 쿨타임

// https://www.youtube.com/watch?v=spqKQfdQPdA <- 피격설정
//Animation Transition 도중 Has Exit Time과 Fixed Duration에 대한 체크 박스를 해제하고 Transition duration과 Transition Offset을 0으로 설정하면 된다.