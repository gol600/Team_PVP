﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireCtrl : MonoBehaviour
{
    public GameObject bullet;

    public Transform firePos;

    public int magicCount;
    private GameObject _enemyFire;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //if(Input.GetKeyDown(KeyCode.R))
        //{
        //
        //    Fire();
        //}
    }

    void Fire()
    {
        //Instantiate(bullet, firePos.position, firePos.rotation);
        var _fireBall = GameManager.instance.GetFireBall();

        if(_fireBall != null)
        {
            _fireBall.transform.position = firePos.position;
            _fireBall.transform.rotation = firePos.rotation;
            _fireBall.SetActive(true);
            magicCount++;
        }

    }

    void FireLightning()
    {
        var _lightningBeam = GameManager.instance.GetLightningBeam();

        if (_lightningBeam != null)
        {
            _lightningBeam.transform.position = firePos.position;
            _lightningBeam.transform.rotation = firePos.rotation;
            _lightningBeam.SetActive(true);
            magicCount++;
        }
    }

    void enemyFire()
    {
        StartCoroutine(this.CreateEnemyFire());
    }

    IEnumerator CreateEnemyFire()
    {
        _enemyFire = Instantiate(bullet, firePos.position, firePos.rotation);
        yield return null;
        
    }



}
