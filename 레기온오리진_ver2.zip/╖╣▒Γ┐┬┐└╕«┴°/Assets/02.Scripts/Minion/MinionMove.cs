﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class MinionMove : MonoBehaviour
{
    private NavMeshAgent agent;
    private MinionCtrl minion;
    private Transform targetTr;

    public readonly float traceSpeed = 7.0f;
    public readonly float Minion_Speed = 8.0f;



    //private bool _returnToPoint;
    //
    //public bool returnToPoint
    //{
    //    get { return _returnToPoint; }
    //    set
    //    {
    //        _returnToPoint = value;
    //        if(_trace)
    //        {
    //            agent.speed = traceSpeed;
    //            moveInRange();
    //        }
    //    }
    //}


    // Start is called before the first frame update
    void Start()
    {
        minion = GetComponent<MinionCtrl>();
        //var player = GameObject.FindGameObjectWithTag("Player");
        //if (player != null)
        //{
        //    targetTr = GetComponent<Transform>();
        //}
        targetTr = GameObject.FindGameObjectWithTag(this.tag).GetComponent<MinionCtrl>().targetTr;
        agent = GetComponent<NavMeshAgent>();


        //agent.enabled = true;
        agent.autoBraking = false;
        agent.speed = 0;


    }
    //void MoveWayPoint()
    //{
    //    // 최단거리 경로 계산 안끝났으면 다음 수행 안함
    //    if (agent.isPathStale) return;
    //
    //    // 다음 목적지 지정
    //    agent.destination = wayPoints[nextIdx].position;
    //    // 내비게이션 기능 활성화(이동 시작)
    //    agent.isStopped = false;
    //
    //}
    //private bool _patrolling;
    //public bool patrolling
    //{
    //    get { return _patrolling; }
    //    set
    //    {
    //        _patrolling = value;
    //        if (_patrolling)
    //        {
    //            agent.speed = Minion_Speed;
    //            MoveWayPoint();
    //        }
    //    }
    //}

    // void moveInRange()
    // {
    //     if (agent.isPathStale) return;
    //     if (jungle.state == EnemyAI.State.RETURN)
    //     {
    //         agent.destination = jungle.genPoints.position;
    //         agent.isStopped = false;
    //     }
    // }
    void TraceTarget(Vector3 pos)
    {
        agent.destination = pos;
        agent.isStopped = false;
    }
    private Vector3 _traceTarget;

    public Vector3 traceTarget
    {
        get { return _traceTarget; }
        set
        {
            _traceTarget = value;
            agent.speed = traceSpeed;
            //Debug.Log(agent.speed);
            TraceTarget(_traceTarget);

        }
    }

    public void Stop()
    {
        agent.isStopped = true;
        agent.velocity = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        //moveInRange();
    }
    

    /*// 순찰 지점 저장
    public List<Transform> wayPoints;
    // 다음 순찰 지점
    public int nextIdx;

    private NavMeshAgent agent;

    private readonly float Minion_Speed = 5.0f;

    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = false;  // 목적지 가까울수록 속도 감소 옵션 비활성화
        agent.speed = Minion_Speed;  // 속도 설정

        // 경로 확인용
        Debug.Log("===== wayPoints =====");
        for (int i = 0; i < wayPoints.Count; i++)
            Debug.Log(wayPoints[i]);
        MoveWayPoint();
    }

    // 다음 목적지까지 이동 명령 내리는 함수
    void MoveWayPoint()
    {
        // 최단거리 경로 계산 안끝났으면 다음 수행 안함
        if (agent.isPathStale) return;

        // 다음 목적지 지정
        agent.destination = wayPoints[nextIdx].position;
        // 내비게이션 기능 활성화(이동 시작)
        agent.isStopped = false;
        
    }

    // Update is called once per frame
    void Update()
    {
        // 순찰 아니면 이후 실행 안함
        if (!_patrolling)
            return;

        if (agent.velocity.sqrMagnitude >= 0.2f * 0.2f && agent.remainingDistance <= 0.5f)
        {
            nextIdx = ++nextIdx % wayPoints.Count;
            MoveWayPoint();
        }
    }

    // 순찰
    private bool _patrolling;
    public bool patrolling
    {
        get { return _patrolling; }
        set
        {
            _patrolling = value;
            if (_patrolling)
            {
                agent.speed = Minion_Speed;
                MoveWayPoint();
            }
        }
    }

    // 추적
    private Vector3 _traceTarget;
    public Vector3 traceTarget
    {
        get { return _traceTarget; }
        set
        {
            _traceTarget = value;
            agent.speed = Minion_Speed;
            TraceTarget(_traceTarget);
        }
    }

    void TraceTarget(Vector3 pos)
    {
        if (agent.isPathStale) return;

        agent.destination = pos;
        agent.isStopped = false;
    }

    // 추적 정지
    public void Stop()
    {
        agent.isStopped = true;
        agent.velocity = Vector3.zero;
        _patrolling = false;
    }
*/
}


// 경로 0이랑 1뿐이니까 수정하자
