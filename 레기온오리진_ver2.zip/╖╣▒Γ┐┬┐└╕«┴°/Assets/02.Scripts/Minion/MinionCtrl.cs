﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class MinionCtrl : MonoBehaviour
{
    // 미니언 상태 정의
    public enum State
    { PATROL, TRACE, CHANGETRACE, ATTACK, DIE }

    // 초기값 저장
    public State state = State.TRACE;

    public Transform targetTr;
    private Transform towerTr;
    public Transform playerTr;
    public Transform enemyTr;

    public GameObject target;
    public GameObject point;

    // 공격, 추적 사정거리
    public float attackDist = 5.0f;
    public float traceDist = 10.0f;

    public GameObject enemy;
    public GameObject tower;
    private float dists;
    private float playerDist;
    private float towerDist;
    private float enemyDist;
    private float dist;
    public float searchDist;
    //private float dist;
    public bool isFirstPointTouch = false;

    // 사망 판단
    public bool isDie = false;

    // 코루틴에서 사용할 지연시간 변수
    private WaitForSeconds ws;
    private MinionMove moveAgent;
    public int minionWay = 0;
    void Start()
    {
        var player = GameObject.FindGameObjectWithTag("Player");

        if (this.tag == "Red")
        {
            tower = GameObject.FindGameObjectWithTag("BlueTeam");
            //enemy = GameObject.FindGameObjectWithTag("Blue");
        }
        if (this.tag == "Blue")
        {
            tower = GameObject.FindGameObjectWithTag("RedTeam");
            //enemy = GameObject.FindGameObjectWithTag("Red");

        }

        if (minionWay == 0)
        {
            point = GameObject.FindGameObjectWithTag("Minion_Bot");
            if (this.tag == "Red")
            {
                tower = GameObject.FindGameObjectWithTag("BlueTeam");
                //enemy = GameObject.FindGameObjectWithTag("Blue");
            }
            if (this.tag == "Blue")
            {
                tower = GameObject.FindGameObjectWithTag("RedTeam");
                //enemy = GameObject.FindGameObjectWithTag("Red");

            }
        }
        else if (minionWay == 1)
        {
            point = GameObject.FindGameObjectWithTag("Minion_Mid");
            if (this.tag == "Red")
            {
                tower = GameObject.FindGameObjectWithTag("BlueTeam");
                //enemy = GameObject.FindGameObjectWithTag("Blue");
            }
            if (this.tag == "Blue")
            {
                tower = GameObject.FindGameObjectWithTag("RedTeam");
                //enemy = GameObject.FindGameObjectWithTag("Red");

            }
        }
        else if (minionWay == 2)
        {
            point = GameObject.FindGameObjectWithTag("Minion_Top");
            if (this.tag == "Red")
            {
                tower = GameObject.FindGameObjectWithTag("BlueTeam");
                //enemy = GameObject.FindGameObjectWithTag("Blue");
            }
            if (this.tag == "Blue")
            {
                tower = GameObject.FindGameObjectWithTag("RedTeam");
                //enemy = GameObject.FindGameObjectWithTag("Red");

            }
        }
        target = point;
        if (player != null)
            playerTr = player.GetComponent<Transform>();
        if (tower != null)
            towerTr = tower.GetComponent<Transform>();
        if (enemy != null)
            enemyTr = enemy.GetComponent<Transform>();

        targetTr = target.GetComponent<Transform>();


        moveAgent = GetComponent<MinionMove>();
        StartCoroutine(checkType());
        StartCoroutine(Action());
    }
    void OnEnable()
    {

    }
    private bool targetPoint = false;
    void getTower()
    {
        GameObject[] taggedEnemys = { null };
        GameObject closestEnemy = null;
        if (this.tag == "Red")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("BlueTeam");

        }
        if (this.tag == "Blue")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("RedTeam");
        }
        float closestDistSqr = Mathf.Infinity;//infinity 실제값?

        foreach (GameObject taggedEnemy in taggedEnemys)
        {
            Vector3 objectPos = taggedEnemy.transform.position;
            dists = Vector3.Distance(objectPos, transform.position);
            //원주민이 특정 거리 안으로 들어올때
            if (dists < searchDist)
            {
                // 그 거리가 제곱한 최단 거리보다 작으면
                //targetPoint = false;
                if (dists < closestDistSqr)
                {
                    closestDistSqr = dists;
                    closestEnemy = taggedEnemy;
                }
            }
        }
        if (closestEnemy != null)
            target = closestEnemy;
        else if (target == null)
        {
            if (targetPoint == true)
            {
                if (this.tag == "Red")
                {
                    target = GameObject.Find("Tower (1)");

                }
                if (this.tag == "Blue")
                {
                    target = GameObject.Find("Tower1");
                }
            }
            else if (targetPoint == false)
            {
                target = point;
            }
        }


    }
    void getEnemy()
    {
        GameObject[] taggedEnemys = { null };
        GameObject closestEnemy = null;
        if (this.tag == "Red")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("Blue");

        }
        if (this.tag == "Blue")
        {
            taggedEnemys = GameObject.FindGameObjectsWithTag("Red");
        }
        float closestDistSqr = Mathf.Infinity;//infinity 실제값?

        foreach (GameObject taggedEnemy in taggedEnemys)
        {
            Vector3 objectPos = taggedEnemy.transform.position;
            dists = Vector3.Distance(objectPos, transform.position);
            //원주민이 특정 거리 안으로 들어올때
            if (dists < searchDist)
            {
                // 그 거리가 제곱한 최단 거리보다 작으면
                if (dists < closestDistSqr)
                {
                    closestDistSqr = dists;
                    closestEnemy = taggedEnemy;
                }
            }
        }
        if (closestEnemy != null)
            target = closestEnemy;
        else if (target == null)
        {
            if (targetPoint == true)
            {
                if (this.tag == "Red")
                {
                    target = GameObject.Find("Tower (1)");

                }
                if (this.tag == "Blue")
                {
                    target = GameObject.Find("Tower1");
                }
            }
            else if (targetPoint == false)
            {
                target = point;
            }
        }


    }
    void Update()
    {
        // 거리에 따라 상태변화
        getEnemy();
        getTower();
        targetTr = target.GetComponent<Transform>();
    }


    IEnumerator checkType()
    {
        while (!isDie)
        {
            //Debug.Log(target);
            //Debug.Log(targetTr);
            dist = Vector3.Distance(this.transform.position, targetTr.position);
            if (state != State.DIE)
            {
                if (dist >= traceDist)
                {
                    state = State.TRACE;
                }
                else if (dist < traceDist && (target == point) || (target == null))
                {
                    targetPoint = true;
                    if (this.tag == "Red")
                    {
                        target = GameObject.Find("Tower (1)");

                    }
                    if (this.tag == "Blue")
                    {
                        target = GameObject.Find("Tower1");
                    }
                    state = State.TRACE;
                }


            }
            yield return ws;
        }
        //while (!isDie)
        //{
        //    if (targetTr != null)
        //    {
        //
        //        playerDist = Vector3.Distance(playerTr.position, this.transform.position);
        //        towerDist = Vector3.Distance(towerTr.position, this.transform.position);
        //        enemyDist = Vector3.Distance(enemyTr.position, this.transform.position);
        //        if (playerDist < towerDist || playerDist < enemyDist)
        //        {
        //            if ((playerTr.GetComponentInParent<PlayerCtrlTest>().redOrBlue != 0 && this.tag != "Blue") || (playerTr.GetComponentInParent<PlayerCtrlTest>().redOrBlue != 1 && this.tag != "Red"))
        //                targetTr = playerTr;
        //
        //        }
        //        else if (towerDist < playerDist || towerDist < enemyDist)
        //        {
        //            targetTr = towerTr;
        //        }
        //        else if (enemyDist < towerDist || enemyDist < playerDist)
        //        {
        //            targetTr = enemyTr;
        //        }
        //        else
        //        {
        //
        //            targetTr = point.transform;
        //
        //        }
        //        Debug.Log(this.tag);
        //
        //    }
        //    float dist = Vector3.Distance(targetTr.position, GameObject.FindGameObjectWithTag(this.tag).transform.position);
        //    yield return ws;
        //    if (dist <= attackDist)
        //    {
        //        if (targetTr != point.transform)
        //            state = State.ATTACK;
        //
        //    }
        //    else if (dist > traceDist)
        //    {
        //        state = State.TRACE;
        //    }
        //    else if (dist < 1 && targetTr == point)
        //    {
        //        if (this.tag == "Red")
        //            targetTr = GameObject.Find("tower (1)").transform;
        //        if (this.tag == "Blue")
        //            targetTr = GameObject.Find("tower").transform;
        //    }
        //
        //}
    }


    // 상태에 따른 행동 처리 코루틴
    IEnumerator Action()
    {
        while (!isDie)
        {
            yield return ws;

            switch (state)
            {


                case State.TRACE:
                    moveAgent.traceTarget = targetTr.position;
                    break;

                case State.ATTACK:
                    moveAgent.Stop();
                    break;

                case State.DIE:
                    moveAgent.Stop();
                    break;
            }
        }
    }
}