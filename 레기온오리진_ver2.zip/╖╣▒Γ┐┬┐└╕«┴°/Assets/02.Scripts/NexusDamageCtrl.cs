﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NexusDamageCtrl : MonoBehaviour
{
    // Start is called before the first frame update
    public bool is_Stun = false;
    public bool is_Die = false;
    public float initHp = 100.0f;
    public float currHp = 100.0f;

    // MP
    public float initMP = 100.0f;
    public float currMP = 100.0f;

    // Attack
    public float attack_damage = 5.0f;
    public float attack_range = 2.0f;

    // Q
    public float q_damage = 6.0f;
    public float q_range = 2.0f;

    // W
    public float w_damage = 7.0f;
    public float w_range = 2.0f;

    // E
    public float e_damage = 8.0f;
    public float e_range = 2.0f;

    // R
    public float r_damage = 9.0f;
    public float r_range = 2.0f;

    public bool playerHit;
    public bool minionHit;
    public bool enemyHit;
    // 피격

    public bool blueTeam;
    public bool redTeam;

    void isDeadTrue()
    {
        is_Die = true;
    }


    void OnTriggerEnter(Collider coll)
    {

        Debug.Log("Enemytouch");


        // 칼 공격
        Debug.Log(coll.gameObject.tag);
        if (coll.gameObject.CompareTag("Sword"))
        {
            Debug.Log("hit");
            //GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().isHit = true;
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().attack_damage;


        }
        if (coll.gameObject.CompareTag("FireMagic") || coll.gameObject.CompareTag("Lightning"))
        {
            Debug.Log("Magichit");
            //GameObject.FindGameObjectWithTag(this.tag).GetComponent<EnemyAI>().isHit = true;
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().q_damage;

            //Destroy(this);
        }
        if (coll.gameObject.CompareTag("FireExplosion"))
        {
            currHp -= GameObject.FindGameObjectWithTag("Player").GetComponent<playerDamageCtrl>().r_damage;
        }
        if (this.gameObject.CompareTag("RedTeam"))
        {
            if (coll.gameObject.CompareTag("Blue"))
            {
                currHp -= coll.gameObject.GetComponent<minionDamageCtrl>().attack_damage;
                Destroy(coll.gameObject);
            }
        }
        if (this.gameObject.CompareTag("BlueTeam"))
        {
            if (coll.gameObject.CompareTag("Red"))
            {
                currHp -= coll.gameObject.GetComponent<minionDamageCtrl>().attack_damage;
                Destroy(coll.gameObject);
            }
        }



    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (currHp <= 0.0f)
        {
            this.gameObject.SetActive(false);
        }
    }
}
